//���� 10
#include <iostream>
#include <string.h>

void encode(char* data, size_t size, int s) {
	char* result = new char[size];
	for (int i = 0; i < size; i++) {
		if (isupper(data[i]))
			data[i] = char(int(data[i] + s - 65) % 26 + 65);
		else
			data[i] = char(int(data[i] + s - 97) % 26 + 97);
	}
	//memcpy(data, result, size);
}

void decode(char* data, size_t size, int s) {
	char* result = new char[size];
	for (int i = 0; i < size; i++) {
		if (isupper(data[i]))
			data[i] = char(int(data[i] - s - 65) % 26 + 65);
		else
			data[i] = char(int(data[i] - s - 97) % 26 + 97);
	}
	//memcpy(data, result, size);
}


void Caser_code(char *array, char *&arr){
	int i=0;
	int key = 10;
	while(array[i] != 0){
		if((array[i] > 64) 
		&& (array[i] < 91) || (array[i] > 96) 
		&& (array[i] < 123)){
			if((array[i]>112) && (array[i] < 123)){
				
			}else if((array[i]>80)	&& (array[i] < 91)){
				
			}else{
				arr[i]=array[i]+key;
				i++;
			}
		}else{
			i++;
		}
	}
}


void fileWrite(char **argv){

	FILE *file;
	file = fopen(argv[1], "w");
	if(file == NULL){
		std::cout<<"ERROR!";
	}else{
		char text[64];
		std::cout<<"Write your text: ";
		std::gets(text);
		fprintf(file, "%s", text);
	}
	fclose(file);
}

void fileRead (char **argv, char *arr){
	
	FILE *file;
	file = fopen (argv[1], "r");
	if(file == NULL){
		std::cout<<"ERROR!";
	}else{
		while(fgets(arr, 64, file) != NULL){
			std::cout<<arr;
		}
	}
	std::cout<<"\n";
	fclose(file);
}

void caser_write(char **argv, char *arr, char *array){

	FILE *file;
	file = fopen(argv[2], "w");
	if(file == NULL){
		std::cout<<"ERROR!";
	}else{
		//std::cout<<arr<<"\n";
		Caser_code(arr, array);
		//std::cout<<array<<"\n";
		fprintf(file, "%s", array);
	}
	fclose(file);
}

int main(int argc, char** argv) {
	
	if(argc<=1){
		std::cout<<"ERROR!";
		return 0;
	}
//	char arr[64] = {0};
//	char array[64] = {0};
//	fileWrite(argv);
//	fileRead(argv, arr);
//	caser_write(argv, arr, array);
	
	char test_str[] = "ABCdefXz";
	encode(test_str, strlen(test_str), 4);
	std::cout << test_str<<std::endl;
	decode(test_str, strlen(test_str), 4);
	std::cout << test_str<<std::endl;
	//std::cout << char(int('Z' + 3 - 65) % 26 + 65);
	return 0;
}
