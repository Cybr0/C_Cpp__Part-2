#include <iostream>
#include <string.h>

struct string_list{
	char *str;
	string_list *prev;
	string_list *next;
};

string_list *add_item(string_list *c_item, char *str){
	
	string_list *new_item = new string_list(); //������ ����� ���������
	new_item->str = new char[strlen(str)];
	strcpy(new_item->str, str);
	new_item->next = 0;
	if(c_item){
		new_item->prev = c_item;
		c_item->next = new_item;
	}else{
		new_item->prev = 0;
	}
	return new_item;
}

void sort_array(string_list *text_list){
	//sorting linked list 
	//���������� ���������� ������
	int k; //
	char x[64];
	
	for(int i = 0; i < size; i++){//while
		k = i;
		strcpy(x , text_list[i]);
		
		for (int j = i + 1; j < size; j++){//while
			if(is_greater(x, text_list[j])){
				k = j;//?
				strcpy(x , text_list[j]);
			}
		}
		strcpy(text_list[k] , text_list[i]);//?
		strcpy(text_list[i] , x);//?
	}
}

string_list *read_file(const char *file_name){
	string_list *ret_val = 0;
	string_list *cur_list_item = 0;
	FILE *file;
	file = fopen(file_name, "r");
	if(file == NULL){
		std::cout<<"damn it!!!"<<std::endl;
	}else{
		char Readfile[64];
		
		while(fscanf(file, "%s", Readfile) != EOF){
			cur_list_item = add_item(cur_list_item, Readfile);
			memset(Readfile,0, 64);
			if(cur_list_item->prev == 0){
				ret_val = cur_list_item;
			}
		}
	}
	fclose(file);
	return ret_val;
}
	
bool is_greater(char *first, char *second){
	int min_size;
	int size_f = strlen(first), size_s = strlen(second);

	bool ret_val;
	
	if(size_f > size_s){ // ������� ��������� ������� ����� ��������,
		min_size = size_s;//� ���������� �� � ���������� ret_val
		ret_val = true;
	}else{
		min_size = size_f;
		ret_val = false;
	}
	for(int i = 0; i < min_size; i++){ // ������� ������ ������� �������,
		if(first[i] > second[i] ){ // � ������.
			return true;
		}else if (first[i] < second[i]){
			return false;
		}
	}
	return ret_val; // ���� ���� For ������������ �������� ret_val
}

void sort_array(char **text_list, int size){
	int k;
	char x[64];
	
	for(int i = 0; i < size; i++){
		k = i;
		strcpy(x , text_list[i]);
		
		for (int j = i + 1; j < size; j++){
			if(is_greater(x, text_list[j])){
				k = j;
				strcpy(x , text_list[j]);
			}
		}
		strcpy(text_list[k] , text_list[i]);
		strcpy(text_list[i] , x);
	}
}

char ** add_string(char **text_list, int &size, char *str){
	size++;
	char ** ret_array = new char* [size];
	
	for(int i = 0; i < size-1; i++){
		ret_array[i] = text_list[i];//
	}
	ret_array[size-1] = new char[strlen(str)];//
	strcpy(ret_array[size-1], str);
	if(text_list){
		delete [] text_list;
	}
	return ret_array;
}

char ** read_file(const char *file_name, int &count){
	count = 0;
	char **ret_list;
	FILE *file;
	file = fopen(file_name, "r");
	if(file == NULL){
		std::cout<<"damn it!!!"<<std::endl;
	}else{
		char Readfile[64];
		while(fscanf(file, "%s", Readfile) != EOF){
			ret_list = add_string(ret_list, count, Readfile);
			memset(Readfile,0, 64);
		}
	}
	fclose(file);
	return ret_list;
}

int main(int argc, char** argv) {

	string_list *list_item = read_file("input.txt");
	
	while(list_item){
		std::cout <<list_item->str <<" ";
		list_item = list_item->next;
	}
//	int word_count = 0;
//	char **word_list = read_file("input.txt", word_count);//new char* [word_count];
//	
//	sort_array(word_list, word_count);
//	
//	for(int i = 0; i < word_count; i++){
//		std::cout << word_list[i]<<std::endl;
//	}
	
	return 0;
}
