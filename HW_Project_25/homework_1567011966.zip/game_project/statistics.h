#include <string>
const int player_count = 6;
struct player{
	std::string name;
	float time;
};

player player_list[player_count];

void clear_player_list(){
	for(int i = 0; i < player_count; i++){
		player_list[i].time = 0;
	}
}

void sort_player_list(){
	int k;
	player x;
	for (int i=0;i<player_count;i++){
		k=i;
		x=player_list[i];
		for (int j=i+1;j<player_count;j++){
			if (player_list[j].time < x.time){
				k=j;
				x=player_list[j];
			}
			player_list[k]=player_list[i];
			player_list[i]=x;
		}

	}	
}

void add_player(std::string n, float t){
	player_list[player_count-1].name = n;
	player_list[player_count-1].time = t;
	sort_player_list();
}

void show_player_list(){
	int counter = 1;
	for(int i = (player_count-1); i >=0; i--){
		if(player_list[i].time != 0){
			std::cout << counter << ". "<<player_list[i].name<<" : "<<player_list[i].time<<"\n";
			counter++;
			if(counter > (player_count-1)){
				return;
			}
		}
	}
}

