#include <iostream>

enum home_info{
	main_menu,
	show_all_flats,
	add_new_flat,
	delete_old_flat
};

struct flat{
	int number_flat;
	int quantity_room;
	int total_area;
};

struct house{
	int	number_house;
	int quantity_flat;
	flat *flat_massiv;
};

home_info show_flats(flat *array, int size);
home_info add_flat(flat *&array, int &size, flat info);
home_info delete_flat(flat *&array, int &size, int index);
home_info menu_struct();

int main(int argc, char** argv) {
	house dom;
	dom.flat_massiv;
	dom.number_house = 1;
	dom.quantity_flat = 0;
	
	home_info Menu = main_menu;
	while(true){
	switch(Menu){
		case main_menu:
			Menu = menu_struct();
		break;
		case show_all_flats:
			Menu = show_flats(dom.flat_massiv, dom.quantity_flat);
		break;
		case add_new_flat:{
			flat kv;
			kv.number_flat = dom.quantity_flat;
			std::cout<<"How many rooms in this flat? ";
			std::cin>>kv.quantity_room;
			std::cout<<"How much total are in this flat? ";
			std::cin>>kv.total_area;
			Menu = add_flat(dom.flat_massiv, dom.quantity_flat, kv);
			break;
		}
		case delete_old_flat:{
			int index;
			std::cout<<"Which flat do you wanna delete?";
			std::cin>>index;
			Menu = delete_flat(dom.flat_massiv, dom.quantity_flat, index-1);
			break;
		}
	}
	}
	
	
	return 0;
}

home_info menu_struct(){
	std::cout<<"1.Show all flats info\n"
	<<"2.Add new flat\n"
	<<"3.Delete any flat\n";
	int index;
	std::cin>>index;
	system("cls");
	switch(index){
		case 1:
			return show_all_flats;
		break;
		case 2:
			return add_new_flat;
		break;
			return delete_old_flat;
		case 3:
		break;
	}
}

home_info show_flats(flat *array, int size){
	for(int i=0; i<size; i++){
		std::cout<<"flat number: "<<array[i].number_flat+1
		<<"  quantity room: "<<array[i].quantity_room<<"  total area: "<<array[i].total_area<<" m(2)\n";
	}	
	return main_menu;
}

home_info add_flat(flat *&array, int &size, flat info){
	flat *arr = new flat [size+1];
	for(int i=0; i<size; i++){
		arr[i]=array[i];
	}
	if(size>0){
		delete [] array;
	}
	arr[size]=info;
	size++;
	array = arr;
	return main_menu;
}

home_info delete_flat(flat *&array, int &size, int index){
	flat *arr = new flat [size-1];
	for(int i=0; i<size-1; i++){
		if(i>=index){
			arr[i]=array[i+1];
		}else{
			arr[i]=array[i];
		}
	}
	if(size>0){
		delete [] array;
	}
	size--;
	array = arr;
	return main_menu;
}

